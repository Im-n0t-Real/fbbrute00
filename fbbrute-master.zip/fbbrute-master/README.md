# fbbrute

Brute force facebook

Install on termux

$ pkg install git

$ pkg install python2

$ git clone https://github.com/sixtysix-Team/fbbrute

$ cd fbbrute

$ pip install requests

$ pip install mechanize

$ pip2 install mechanize

$ python2 force.py
